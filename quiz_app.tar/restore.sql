--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Ubuntu 14.7-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.7 (Ubuntu 14.7-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE quiz_app;
--
-- Name: quiz_app; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE quiz_app WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE quiz_app OWNER TO postgres;

\connect quiz_app

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mappers; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA mappers;


ALTER SCHEMA mappers OWNER TO postgres;

--
-- Name: quiz; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA quiz;


ALTER SCHEMA quiz OWNER TO postgres;

--
-- Name: utils; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA utils;


ALTER SCHEMA utils OWNER TO postgres;

--
-- Name: create_activity_dto; Type: TYPE; Schema: quiz; Owner: postgres
--

CREATE TYPE quiz.create_activity_dto AS (
	user_id bigint,
	language_id smallint,
	subject_id smallint
);


ALTER TYPE quiz.create_activity_dto OWNER TO postgres;

--
-- Name: create_question_history_dto; Type: TYPE; Schema: quiz; Owner: postgres
--

CREATE TYPE quiz.create_question_history_dto AS (
	activity_id bigint,
	quiz_id bigint,
	user_answer character varying
);


ALTER TYPE quiz.create_question_history_dto OWNER TO postgres;

--
-- Name: create_quiz_dto; Type: TYPE; Schema: quiz; Owner: postgres
--

CREATE TYPE quiz.create_quiz_dto AS (
	subject_id bigint,
	question character varying,
	locale smallint,
	quiz_id bigint,
	correct_answer character varying,
	level_id smallint,
	answers json
);


ALTER TYPE quiz.create_quiz_dto OWNER TO postgres;

--
-- Name: to_create_activity_dto(json); Type: FUNCTION; Schema: mappers; Owner: postgres
--

CREATE FUNCTION mappers.to_create_activity_dto(activity json) RETURNS quiz.create_activity_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    dto create_activity_dto;
begin
    dto.user_id = activity ->> 'userId';
    dto.subject_id = activity ->> 'subjectId';
    dto.language_id = activity ->> 'languageId';
    return dto;
end;
$$;


ALTER FUNCTION mappers.to_create_activity_dto(activity json) OWNER TO postgres;

--
-- Name: to_create_question_history_dto(json); Type: FUNCTION; Schema: mappers; Owner: postgres
--

CREATE FUNCTION mappers.to_create_question_history_dto(question_history json) RETURNS quiz.create_question_history_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    dto create_question_history_dto;
begin
    dto.activity_id = question_history ->> 'activityId';
    dto.quiz_id = question_history ->> 'quizId';
    dto.user_answer = question_history ->> 'userAnswer';
    return dto;
end;
$$;


ALTER FUNCTION mappers.to_create_question_history_dto(question_history json) OWNER TO postgres;

--
-- Name: to_create_quiz_dto(json); Type: FUNCTION; Schema: mappers; Owner: postgres
--

CREATE FUNCTION mappers.to_create_quiz_dto(quiz json) RETURNS quiz.create_quiz_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    dto create_quiz_dto;
begin
    dto.subject_id = quiz ->> 'subject_id';
    dto.question = quiz ->> 'question';
    dto.correct_answer = quiz ->> 'correct_answer';
    dto.locale = quiz ->> 'language_id';
    dto.level_id = quiz ->> 'level_id';
    dto.answers = quiz -> 'answers';
    return dto;
end;
$$;


ALTER FUNCTION mappers.to_create_quiz_dto(quiz json) OWNER TO postgres;

--
-- Name: add_language_quiz(text, bigint, bigint); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.add_language_quiz(dataparam text, i_quiz_id bigint, user_id bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    j_quiz     json;
    dto        quiz.create_quiz_dto;
    answer_arr varchar;
    answerid   bigint;
begin
    call utils.is_active(user_id);
    if utils.has_role(user_id, 'user') = true then
        raise exception 'user role is not admin or mentor';
    end if;

    j_quiz = get_json(dataparam);
    dto = mappers.to_create_quiz_dto(j_quiz);
    if  check_param_of_add_language_quiz(dto) = false then
        raise exception 'answers error';
    end if;

    for answer_arr in select json_array_elements(dto.answers)
        loop
            insert into quiz.answer(quiz_id) values (i_quiz_id) returning id into answerid;
            insert into quiz.localized_answer(locale, answer_id, answer) VALUES (dto.locale, answerid, answer_arr);
        end loop;

    insert into quiz.localized_quiz(question, locale, quiz_id, correct_answer)
    values (dto.question, dto.locale, i_quiz_id, dto.correct_answer);

    return 'succesfully ...';
end;
$$;


ALTER FUNCTION quiz.add_language_quiz(dataparam text, i_quiz_id bigint, user_id bigint) OWNER TO postgres;

--
-- Name: check_create_activity_dto_param(quiz.create_activity_dto); Type: PROCEDURE; Schema: quiz; Owner: postgres
--

CREATE PROCEDURE quiz.check_create_activity_dto_param(IN dto quiz.create_activity_dto)
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    raise info '%', dto.user_id;
    if dto.user_id is null or not exists(select * from users where id = dto.user_id) then
        raise exception 'user_id invalid';
    end if;
    if dto.subject_id is null or not exists(select * from subject where id = dto.subject_id) then
        raise exception 'subject_id invalid';
    end if;
    if dto.language_id is null or not exists(select * from language where id = dto.language_id) then
        raise exception 'language_id invalid';
    end if;
end;
$$;


ALTER PROCEDURE quiz.check_create_activity_dto_param(IN dto quiz.create_activity_dto) OWNER TO postgres;

--
-- Name: check_param_of_add_language_quiz(quiz.create_quiz_dto); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.check_param_of_add_language_quiz(dto quiz.create_quiz_dto) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
    answer varchar;
begin

    if dto.question is null or length(dto.question) = 0 then
        raise exception 'question error';
    end if;
    if dto.correct_answer is null then
        raise exception 'correct_answer error';
    end if;
    if dto.locale is null or not exists(select * from language where id = dto.locale) then
        raise exception 'locale error';
    end if;
    if dto.level_id is null or not exists(select * from level where id = dto.level_id) then
        raise exception 'locale error';
    end if;

    if dto.answers is null or dto.answers::text not like '[%' or dto.answers::text = '[]' then
        raise exception 'answer error';
    end if;
    for answer in select json_array_elements(dto.answers)
        loop
            if answer = ('"' || dto.correct_answer || '"') then
                return true;
            end if;
        end loop;
    return false;
end;
$$;


ALTER FUNCTION quiz.check_param_of_add_language_quiz(dto quiz.create_quiz_dto) OWNER TO postgres;

--
-- Name: check_param_of_create_quiz_dto(quiz.create_quiz_dto); Type: PROCEDURE; Schema: quiz; Owner: postgres
--

CREATE PROCEDURE quiz.check_param_of_create_quiz_dto(IN dto quiz.create_quiz_dto)
    LANGUAGE plpgsql
    AS $$
declare
    answer varchar;
begin
    if dto.subject_id is null or not exists(select * from subject where id = dto.subject_id) then
        raise exception 'subject_id error';
    end if;
    if dto.question is null or length(dto.question) = 0 then
        raise exception 'question error';
    end if;
    if dto.correct_answer is null then
        raise exception 'correct_answer error';
    end if;
    if dto.locale is null or not exists(select * from language where id = dto.locale) then
        raise exception 'locale error';
    end if;
    if dto.level_id is null or not exists(select * from level where id = dto.level_id) then
        raise exception 'level error';
    end if;
    if dto.answers is null or dto.answers::text = '[]' then
        raise exception 'answer error';
    end if;
    for answer in select json_array_elements(dto.answers)
        loop
            if answer = dto.correct_answer then
                return;
            end if;
        end loop;
    raise exception 'correct_answer error';
end;
$$;


ALTER PROCEDURE quiz.check_param_of_create_quiz_dto(IN dto quiz.create_quiz_dto) OWNER TO postgres;

--
-- Name: check_param_of_u_quiz_dto(quiz.create_quiz_dto); Type: PROCEDURE; Schema: quiz; Owner: postgres
--

CREATE PROCEDURE quiz.check_param_of_u_quiz_dto(IN dto quiz.create_quiz_dto)
    LANGUAGE plpgsql
    AS $$
declare
    answer varchar;
begin

    if dto.question is null or length(dto.question) = 0 then
        raise exception 'question error';
    end if;
    if dto.correct_answer is null then
        raise exception 'correct_answer error';
    end if;
    if dto.locale is null or not exists(select * from language where id = dto.locale) then
        raise exception 'locale error';
    end if;

    if dto.answers is null or dto.answers::text = '[]' then
        raise exception 'answer error';
    end if;
    for answer in select json_array_elements(dto.answers)
        loop
            if answer = dto.correct_answer then
                return;
            end if;
        end loop;
    raise exception 'correct_answer error';
end;
$$;


ALTER PROCEDURE quiz.check_param_of_u_quiz_dto(IN dto quiz.create_quiz_dto) OWNER TO postgres;

--
-- Name: check_to_create_question_history_dto(quiz.create_question_history_dto); Type: PROCEDURE; Schema: quiz; Owner: postgres
--

CREATE PROCEDURE quiz.check_to_create_question_history_dto(IN dto quiz.create_question_history_dto)
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    if dto.activity_id is null or not exists(select * from activity where id = dto.activity_id) then
        raise exception 'activity_id invalid';
    end if;
    if dto.quiz_id is null or not exists(select * from quiz where id = dto.quiz_id) then
        raise exception 'quiz_id invalid';
    end if;
    if dto.user_answer is null or length(dto.user_answer) = 0 then
        raise exception 'user_answer invalid';
    end if;
end;
$$;


ALTER PROCEDURE quiz.check_to_create_question_history_dto(IN dto quiz.create_question_history_dto) OWNER TO postgres;

--
-- Name: create_activity(text); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.create_activity(dataparam text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    r_json json;
    dto    create_activity_dto;
    activity_id bigint;
begin
    r_json = get_json(dataparam);
    dto = mappers.to_create_activity_dto(r_json);

    call check_create_activity_dto_param(dto);

    insert into activity (user_id, subject_id, language_id)
    values (dto.user_id, dto.subject_id, dto.language_id)
    returning id into activity_id;

    return activity_id;
end;
$$;


ALTER FUNCTION quiz.create_activity(dataparam text) OWNER TO postgres;

--
-- Name: create_question_history(text); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.create_question_history(dataparam text) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    r_json      json;
    dto         create_question_history_dto;
    found       boolean = false;
    question_id bigint;
begin
    r_json = get_json(dataparam);
    dto = mappers.to_create_question_history_dto(r_json);

    call check_to_create_question_history_dto(dto);

    if exists(select *
                  from quiz q
                           join localized_quiz l on q.id = l.quiz_id
                  where l.correct_answer = dto.user_answer) then
                       raise info '%', dto.user_answer;
        found = true;
    end if;

    insert into question_history (activity_id, quiz_id, user_answer, has_found)
    values (dto.activity_id, dto.quiz_id, dto.user_answer, found)
    returning id into question_id;

    return question_id;
end;
$$;


ALTER FUNCTION quiz.create_question_history(dataparam text) OWNER TO postgres;

--
-- Name: create_quiz(text, bigint); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.create_quiz(data_param text, user_id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    j_quiz  json;
    dto     quiz.create_quiz_dto;
    quiz_id bigint;
begin
    call utils.is_active(user_id);
    if utils.has_role(user_id, 'user') = true then
        raise exception 'user role is not admin or mentor';
    end if;

    j_quiz = get_json(data_param);

    dto = mappers.to_create_quiz_dto(j_quiz);

    if dto.subject_id is null or not exists(select * from subject where id = dto.subject_id) then
        raise exception 'subject_id error';
    end if;
    if dto.level_id is null or not exists(select * from level where id = dto.level_id) then
        raise exception 'level error';
    end if;

    insert into quiz.quiz (subject_id, created_by, level_id)
    VALUES (dto.subject_id, user_id, dto.level_id)
    returning id into quiz_id;

    if add_language_quiz(data_param, quiz_id, user_id) <> 'succesfully ...' then
        raise exception 'error';
    end if;

    return quiz_id;
end;
$$;


ALTER FUNCTION quiz.create_quiz(data_param text, user_id bigint) OWNER TO postgres;

--
-- Name: get_activities(bigint, bigint, integer); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.get_activities(i_user bigint, i_offset bigint, i_limit integer) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    call is_active(i_user);

    return ( coalesce((select json_agg(json_build_object(
            'languageInfo', language_info(a.language_id),
            'startedAt', a.started_at,
            'subjectInfo', subjectInfo(a.subject_id, a.language_id),
            'quiz', quizInfo(a.id, a.language_id)
        ))
                       from quiz.activity a
                       where a.deleted = false
                         and a.user_id = i_user
         offset i_offset limit i_limit),
                      '[]'));
end;
$$;


ALTER FUNCTION quiz.get_activities(i_user bigint, i_offset bigint, i_limit integer) OWNER TO postgres;

--
-- Name: get_answers(bigint, smallint); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.get_answers(quizid bigint, language_id smallint) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    return (select json_agg(json_build_object(
        'id', a.id,
        'answer', l.answer
        )) from answer a join localized_answer l on a.id = l.answer_id
           where a.quiz_id = quizid and l.locale = language_id);
end;
$$;


ALTER FUNCTION quiz.get_answers(quizid bigint, language_id smallint) OWNER TO postgres;

--
-- Name: get_json(text); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.get_json(i_json text) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    if i_json is null or i_json = '' or i_json = '{}' then
        raise exception 'dataparam is invalid';
    end if;

    return i_json::json;
end;
$$;


ALTER FUNCTION quiz.get_json(i_json text) OWNER TO postgres;

--
-- Name: language_info(smallint); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.language_info(language_id smallint) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    return (select json_build_object(
        'id', l.id,
        'name', l.name,
        'short_name', l.short_name
        ) from language l where id = language_id);
end;
$$;


ALTER FUNCTION quiz.language_info(language_id smallint) OWNER TO postgres;

--
-- Name: levelinfo(smallint, smallint); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.levelinfo(levelid smallint, language_id smallint) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    return (select json_build_object(
        'name',ll.name
                       ) from level l join localized_level ll on l.id = ll.level_id
                         where l.id = levelid and ll.locale = language_id);
end;
$$;


ALTER FUNCTION quiz.levelinfo(levelid smallint, language_id smallint) OWNER TO postgres;

--
-- Name: quizinfo(bigint, smallint); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.quizinfo(a_id bigint, language_id smallint) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    return (select json_agg(json_build_object(
            'createdBy', utils.user_info(q.created_by),
            'createdAt', q.created_at,
            'level', levelInfo(q.level_id, language_id),
            'question', l.question,
            'answers', get_answers(qh.quiz_id, language_id),
        'userAnswer', qh.user_answer,
        'hasFound', qh.has_found,
        'solvedAt', qh.solved_at
        ))
            from question_history qh
                     join quiz q on qh.quiz_id = q.id
                     join localized_quiz l on l.quiz_id = q.id
            where q.deleted = false
              and qh.activity_id = a_id
              and l.locale = language_id) ;
end;
$$;


ALTER FUNCTION quiz.quizinfo(a_id bigint, language_id smallint) OWNER TO postgres;

--
-- Name: solve_quiz(bigint, bigint, character varying); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.solve_quiz(i_user_id bigint, i_quiz_id bigint, user_answer character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
    is_correct       bool := false;
    i_correct_answer varchar;
    i_lan_id         bigint;
    i_subject_id     bigint;
    i_activity_id    bigint;
begin
    select *
    into i_subject_id
    from quiz q
             join subject s on q.subject_id = s.id
    where q.id = i_quiz_id;
    select language_id into i_lan_id from users where id = i_user_id;
    select correct_answer
    into i_correct_answer
    from localized_quiz lq
    where lq.quiz_id = i_quiz_id
      and locale = i_lan_id;
    if user_answer ilike i_correct_answer then
        is_correct := true;
    end if;
    select * from activity where user_id = i_user_id;
    if not FOUND then
        select * into i_activity_id
        from create_activity('{"userId":' || i_user_id || ', "subjectId":' || i_subject_id ||
                             '", languageId":' || i_lan_id||'}');
        else
        select id into i_activity_id from activity where user_id = i_user_id;
    end if;

    select * from quiz.create_question_history('{"activityId":'||i_activity_id||', "quizId":'||
        i_quiz_id||', "userAnswer":'||user_answer||'}');

    return is_correct;
end ;
$$;


ALTER FUNCTION quiz.solve_quiz(i_user_id bigint, i_quiz_id bigint, user_answer character varying) OWNER TO postgres;

--
-- Name: subjectinfo(smallint, smallint); Type: FUNCTION; Schema: quiz; Owner: postgres
--

CREATE FUNCTION quiz.subjectinfo(i_subject_id smallint, language_id smallint) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
begin
    return (select json_build_object(
                           'id', s.id,
                           'createdAt', s.created_at,
                           'createdBy', utils.user_info(s.created_by),
                           'name', l.name
                       )
            from subject s
                     join localized_subject l on s.id = l.subject_id
            where s.is_deleted = false
              and s.id = i_subject_id
              and l.locale = language_id);
end ;
$$;


ALTER FUNCTION quiz.subjectinfo(i_subject_id smallint, language_id smallint) OWNER TO postgres;

--
-- Name: has_role(bigint, character varying); Type: FUNCTION; Schema: utils; Owner: postgres
--

CREATE FUNCTION utils.has_role(user_id bigint DEFAULT NULL::bigint, role character varying DEFAULT NULL::character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
    t_user record;
BEGIN
    if user_id is null or role is null then
        return false;
    end if;
    select * into t_user from quiz.users t where t.active = 0 and t.id = user_id;
    return FOUND and t_user.role ilike role;
END
$$;


ALTER FUNCTION utils.has_role(user_id bigint, role character varying) OWNER TO postgres;

--
-- Name: is_active(bigint); Type: PROCEDURE; Schema: utils; Owner: postgres
--

CREATE PROCEDURE utils.is_active(IN userid bigint DEFAULT NULL::bigint)
    LANGUAGE plpgsql
    AS $$
declare
    t_user record;
BEGIN
    if userid is null then
        raise exception 'User id is null';
    end if;

    select * into t_user from users t where t.active = 0 and t.id = userid;
    if not FOUND then
        raise exception 'User not found by id : ''%''',userid;
    end if;
END
$$;


ALTER PROCEDURE utils.is_active(IN userid bigint) OWNER TO postgres;

--
-- Name: user_info(bigint); Type: FUNCTION; Schema: utils; Owner: postgres
--

CREATE FUNCTION utils.user_info(user_id bigint DEFAULT NULL::bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
    r_user record;
begin
    select * into r_user from quiz.users u where u.active = 0 and u.id = user_id;
    if FOUND then
        return row_to_json(X)::jsonb
            FROM (SELECT r_user.id, r_user.username, r_user.email, r_user.language_id, r_user.role) AS X;
    else
        return null;
    end if;
end
$$;


ALTER FUNCTION utils.user_info(user_id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.activity (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    language_id smallint NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    subject_id smallint NOT NULL,
    deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE quiz.activity OWNER TO postgres;

--
-- Name: activity_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.activity ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: answer; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.answer (
    id bigint NOT NULL,
    quiz_id bigint NOT NULL
);


ALTER TABLE quiz.answer OWNER TO postgres;

--
-- Name: answer_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.answer ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.answer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: language; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.language (
    id smallint NOT NULL,
    name character varying NOT NULL,
    short_name character varying NOT NULL
);


ALTER TABLE quiz.language OWNER TO postgres;

--
-- Name: language_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.language ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.language_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: level; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.level (
    id smallint NOT NULL
);


ALTER TABLE quiz.level OWNER TO postgres;

--
-- Name: level_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.level ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.level_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: localized_answer; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.localized_answer (
    id bigint NOT NULL,
    locale smallint NOT NULL,
    answer_id bigint NOT NULL,
    answer character varying NOT NULL
);


ALTER TABLE quiz.localized_answer OWNER TO postgres;

--
-- Name: localized_answer_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.localized_answer ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.localized_answer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: localized_level; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.localized_level (
    id smallint NOT NULL,
    locale smallint NOT NULL,
    level_id smallint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE quiz.localized_level OWNER TO postgres;

--
-- Name: localized_level_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.localized_level ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.localized_level_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: localized_quiz; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.localized_quiz (
    id bigint NOT NULL,
    question character varying NOT NULL,
    locale smallint NOT NULL,
    quiz_id bigint NOT NULL,
    correct_answer character varying NOT NULL
);


ALTER TABLE quiz.localized_quiz OWNER TO postgres;

--
-- Name: localized_quiz_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.localized_quiz ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.localized_quiz_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: localized_subject; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.localized_subject (
    id bigint NOT NULL,
    subject_id bigint NOT NULL,
    locale smallint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE quiz.localized_subject OWNER TO postgres;

--
-- Name: localized_subject_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.localized_subject ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.localized_subject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: question_history; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.question_history (
    id bigint NOT NULL,
    activity_id bigint NOT NULL,
    quiz_id bigint NOT NULL,
    user_answer character varying NOT NULL,
    has_found boolean DEFAULT false NOT NULL,
    solved_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE quiz.question_history OWNER TO postgres;

--
-- Name: question_history_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.question_history ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.question_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: quiz; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.quiz (
    id bigint NOT NULL,
    subject_id bigint NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    level_id smallint NOT NULL
);


ALTER TABLE quiz.quiz OWNER TO postgres;

--
-- Name: quiz_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.quiz ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.quiz_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: subject; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.subject (
    id smallint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by bigint NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE quiz.subject OWNER TO postgres;

--
-- Name: subject_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.subject ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.subject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.users (
    id bigint NOT NULL,
    username character varying NOT NULL,
    fullname character varying NOT NULL,
    password character varying NOT NULL,
    language_id smallint DEFAULT 1 NOT NULL,
    role character varying DEFAULT 'USER'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    active smallint DEFAULT 0 NOT NULL,
    email character varying NOT NULL
);


ALTER TABLE quiz.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: quiz; Owner: postgres
--

ALTER TABLE quiz.users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME quiz.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: activity; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.activity (id, user_id, language_id, started_at, subject_id, deleted) FROM stdin;
\.
COPY quiz.activity (id, user_id, language_id, started_at, subject_id, deleted) FROM '$$PATH$$/3524.dat';

--
-- Data for Name: answer; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.answer (id, quiz_id) FROM stdin;
\.
COPY quiz.answer (id, quiz_id) FROM '$$PATH$$/3528.dat';

--
-- Data for Name: language; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.language (id, name, short_name) FROM stdin;
\.
COPY quiz.language (id, name, short_name) FROM '$$PATH$$/3508.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.level (id) FROM stdin;
\.
COPY quiz.level (id) FROM '$$PATH$$/3518.dat';

--
-- Data for Name: localized_answer; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.localized_answer (id, locale, answer_id, answer) FROM stdin;
\.
COPY quiz.localized_answer (id, locale, answer_id, answer) FROM '$$PATH$$/3530.dat';

--
-- Data for Name: localized_level; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.localized_level (id, locale, level_id, name) FROM stdin;
\.
COPY quiz.localized_level (id, locale, level_id, name) FROM '$$PATH$$/3520.dat';

--
-- Data for Name: localized_quiz; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.localized_quiz (id, question, locale, quiz_id, correct_answer) FROM stdin;
\.
COPY quiz.localized_quiz (id, question, locale, quiz_id, correct_answer) FROM '$$PATH$$/3522.dat';

--
-- Data for Name: localized_subject; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.localized_subject (id, subject_id, locale, name) FROM stdin;
\.
COPY quiz.localized_subject (id, subject_id, locale, name) FROM '$$PATH$$/3514.dat';

--
-- Data for Name: question_history; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.question_history (id, activity_id, quiz_id, user_answer, has_found, solved_at) FROM stdin;
\.
COPY quiz.question_history (id, activity_id, quiz_id, user_answer, has_found, solved_at) FROM '$$PATH$$/3526.dat';

--
-- Data for Name: quiz; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.quiz (id, subject_id, created_by, created_at, deleted, level_id) FROM stdin;
\.
COPY quiz.quiz (id, subject_id, created_by, created_at, deleted, level_id) FROM '$$PATH$$/3516.dat';

--
-- Data for Name: subject; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.subject (id, created_at, created_by, is_deleted) FROM stdin;
\.
COPY quiz.subject (id, created_at, created_by, is_deleted) FROM '$$PATH$$/3510.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.users (id, username, fullname, password, language_id, role, created_at, active, email) FROM stdin;
\.
COPY quiz.users (id, username, fullname, password, language_id, role, created_at, active, email) FROM '$$PATH$$/3512.dat';

--
-- Name: activity_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.activity_id_seq', 1, true);


--
-- Name: answer_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.answer_id_seq', 41, true);


--
-- Name: language_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.language_id_seq', 1, true);


--
-- Name: level_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.level_id_seq', 1, true);


--
-- Name: localized_answer_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.localized_answer_id_seq', 41, true);


--
-- Name: localized_level_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.localized_level_id_seq', 3, true);


--
-- Name: localized_quiz_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.localized_quiz_id_seq', 15, true);


--
-- Name: localized_subject_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.localized_subject_id_seq', 1, true);


--
-- Name: question_history_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.question_history_id_seq', 6, true);


--
-- Name: quiz_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.quiz_id_seq', 42, true);


--
-- Name: subject_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.subject_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: quiz; Owner: postgres
--

SELECT pg_catalog.setval('quiz.users_id_seq', 3, true);


--
-- Name: activity activity_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id);


--
-- Name: answer answer_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.answer
    ADD CONSTRAINT answer_pkey PRIMARY KEY (id);


--
-- Name: language language_name_key; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.language
    ADD CONSTRAINT language_name_key UNIQUE (name);


--
-- Name: language language_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.language
    ADD CONSTRAINT language_pkey PRIMARY KEY (id);


--
-- Name: language language_short_name_key; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.language
    ADD CONSTRAINT language_short_name_key UNIQUE (short_name);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id);


--
-- Name: localized_answer localized_answer_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_answer
    ADD CONSTRAINT localized_answer_pkey PRIMARY KEY (id);


--
-- Name: localized_level localized_level_name_key; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_level
    ADD CONSTRAINT localized_level_name_key UNIQUE (name);


--
-- Name: localized_level localized_level_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_level
    ADD CONSTRAINT localized_level_pkey PRIMARY KEY (id);


--
-- Name: localized_quiz localized_quiz_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_quiz
    ADD CONSTRAINT localized_quiz_pkey PRIMARY KEY (id);


--
-- Name: localized_quiz localized_quiz_question_key; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_quiz
    ADD CONSTRAINT localized_quiz_question_key UNIQUE (question);


--
-- Name: localized_subject localized_subject_name_key; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_subject
    ADD CONSTRAINT localized_subject_name_key UNIQUE (name);


--
-- Name: localized_subject localized_subject_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_subject
    ADD CONSTRAINT localized_subject_pkey PRIMARY KEY (id);


--
-- Name: question_history question_history_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.question_history
    ADD CONSTRAINT question_history_pkey PRIMARY KEY (id);


--
-- Name: quiz quiz_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.quiz
    ADD CONSTRAINT quiz_pkey PRIMARY KEY (id);


--
-- Name: subject subject_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.subject
    ADD CONSTRAINT subject_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: activity activity_language_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.activity
    ADD CONSTRAINT activity_language_id_fkey FOREIGN KEY (language_id) REFERENCES quiz.language(id);


--
-- Name: activity activity_subject_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.activity
    ADD CONSTRAINT activity_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES quiz.subject(id);


--
-- Name: activity activity_user_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.activity
    ADD CONSTRAINT activity_user_id_fkey FOREIGN KEY (user_id) REFERENCES quiz.users(id);


--
-- Name: localized_answer localized_answer_answer_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_answer
    ADD CONSTRAINT localized_answer_answer_id_fkey FOREIGN KEY (answer_id) REFERENCES quiz.answer(id);


--
-- Name: localized_answer localized_answer_locale_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_answer
    ADD CONSTRAINT localized_answer_locale_fkey FOREIGN KEY (locale) REFERENCES quiz.language(id);


--
-- Name: localized_level localized_level_level_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_level
    ADD CONSTRAINT localized_level_level_id_fkey FOREIGN KEY (level_id) REFERENCES quiz.level(id);


--
-- Name: localized_level localized_level_locale_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_level
    ADD CONSTRAINT localized_level_locale_fkey FOREIGN KEY (locale) REFERENCES quiz.language(id);


--
-- Name: localized_quiz localized_quiz_locale_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_quiz
    ADD CONSTRAINT localized_quiz_locale_fkey FOREIGN KEY (locale) REFERENCES quiz.language(id);


--
-- Name: localized_quiz localized_quiz_quiz_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_quiz
    ADD CONSTRAINT localized_quiz_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES quiz.quiz(id);


--
-- Name: localized_subject localized_subject_locale_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_subject
    ADD CONSTRAINT localized_subject_locale_fkey FOREIGN KEY (locale) REFERENCES quiz.language(id);


--
-- Name: localized_subject localized_subject_subject_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.localized_subject
    ADD CONSTRAINT localized_subject_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES quiz.subject(id);


--
-- Name: question_history question_history_activity_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.question_history
    ADD CONSTRAINT question_history_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES quiz.activity(id);


--
-- Name: question_history question_history_quiz_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.question_history
    ADD CONSTRAINT question_history_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES quiz.quiz(id);


--
-- Name: quiz quiz_created_by_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.quiz
    ADD CONSTRAINT quiz_created_by_fkey FOREIGN KEY (created_by) REFERENCES quiz.users(id);


--
-- Name: quiz quiz_level_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.quiz
    ADD CONSTRAINT quiz_level_id_fkey FOREIGN KEY (level_id) REFERENCES quiz.level(id);


--
-- Name: quiz quiz_subject_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.quiz
    ADD CONSTRAINT quiz_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES quiz.subject(id);


--
-- Name: subject subject_created_by_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.subject
    ADD CONSTRAINT subject_created_by_fkey FOREIGN KEY (created_by) REFERENCES quiz.users(id);


--
-- Name: users users_language_id_fkey; Type: FK CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.users
    ADD CONSTRAINT users_language_id_fkey FOREIGN KEY (language_id) REFERENCES quiz.language(id);


--
-- PostgreSQL database dump complete
--

